variable "location" {
  description = "Região do Azure onde os recursos serão provisionados (igual ao template: eastus2)"
  type        = string
  default     = "eastus2"
}

variable "resource_group_name" {
  description = "Resource Group da versão IaC da VM (separado do rg-lab-aula01 criado no portal)"
  type        = string
  default     = "rg-iac-aula01"
}

variable "vm_size" {
  description = "Tamanho da VM (igual ao template exportado do portal — Standard_D2ps_v6, série Arm Cobalt)"
  type        = string
  default     = "Standard_D2ps_v6"
}

variable "zone" {
  description = "Availability Zone da VM (igual ao template: zona 1)"
  type        = string
  default     = "1"
}

variable "admin_username" {
  description = "Usuário administrador da VM"
  type        = string
  default     = "azureuser"
}

variable "ssh_public_key_path" {
  description = "Caminho da chave pública SSH usada para acessar a VM (no Cloud Shell: ~/.ssh/id_rsa.pub)"
  type        = string
  default     = "~/.ssh/id_rsa.pub"
}

# sem default de propósito - obriga passar -var="meu_ip=$(curl -s ifconfig.me)" toda vez,
# em vez de deixar um IP fixo hardcoded no código versionado
variable "meu_ip" {
  description = "IP público de origem autorizado a acessar a porta 22 (SSH) da VM. Obtenha com `curl ifconfig.me` no Cloud Shell."
  type        = string

  validation {
    condition     = can(regex("^\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}$", var.meu_ip))
    error_message = "meu_ip deve ser um endereço IPv4 válido, sem a máscara /32 (ela é adicionada automaticamente na regra do NSG)."
  }
}
