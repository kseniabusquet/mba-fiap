// Lab da Aula 1 (RG + VNet + Subnet + NSG + IP + NIC + VM Linux) traduzido de
// Terraform pra Bicep, já com o hardening do Exercício 3.1 (SSH restrito ao
// meuIp, subnet-app extra).
//
// Deploy (Cloud Shell, escopo de Resource Group já existente):
//
//   az group create --name rg-bicep-aula01 --location eastus2
//
//   az deployment group create \
//     --resource-group rg-bicep-aula01 \
//     --template-file main.bicep \
//     --parameters adminPublicKey="$(cat ~/.ssh/id_rsa.pub)" meuIp="$(curl -s ifconfig.me)"
//
//   az group delete --name rg-bicep-aula01 --yes --no-wait   # não esquecer de destruir

@description('Região do Azure onde os recursos serão provisionados')
param location string = resourceGroup().location

@description('Usuário administrador da VM')
param adminUsername string = 'azureuser'

@description('Chave pública SSH usada para acessar a VM (conteúdo de ~/.ssh/id_rsa.pub)')
@secure()
param adminPublicKey string

@description('IP público de origem autorizado a acessar a porta 22 (SSH). Obtenha com `curl ifconfig.me`.')
param meuIp string

@description('Tamanho da VM (paridade com o Terraform — Standard_D2ps_v6, série Arm Cobalt)')
param vmSize string = 'Standard_D2ps_v6'

@description('Availability Zone da VM')
param zone string = '1'

var tags = {
  aula: '1'
  disciplina: 'cloud-cognitive'
  provisionado: 'bicep'
  grupo: 'qc-grupo-02'
}

// vnet 10.0.0.0/16 com subnet default (10.0.0.0/24) e subnet-app (10.0.2.0/24),
// equivalente ao main.tf endurecido do Exercício 3.1
resource vnet 'Microsoft.Network/virtualNetworks@2023-09-01' = {
  name: 'vm-lab-aula01-vnet'
  location: location
  tags: tags
  properties: {
    addressSpace: {
      addressPrefixes: [
        '10.0.0.0/16'
      ]
    }
    subnets: [
      {
        name: 'default'
        properties: {
          addressPrefix: '10.0.0.0/24'
        }
      }
      {
        name: 'subnet-app'
        properties: {
          addressPrefix: '10.0.2.0/24'
        }
      }
    ]
  }
}

// SSH restrito ao meuIp, HTTP/HTTPS continuam públicos de propósito
resource nsg 'Microsoft.Network/networkSecurityGroups@2023-09-01' = {
  name: 'vm-lab-aula01-nsg'
  location: location
  tags: tags
  properties: {
    securityRules: [
      {
        name: 'SSH'
        properties: {
          priority: 300
          direction: 'Inbound'
          access: 'Allow'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '22'
          sourceAddressPrefix: '${meuIp}/32'
          destinationAddressPrefix: '*'
        }
      }
      {
        name: 'HTTPS'
        properties: {
          priority: 320
          direction: 'Inbound'
          access: 'Allow'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '443'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: '*'
        }
      }
      {
        name: 'HTTP'
        properties: {
          priority: 340
          direction: 'Inbound'
          access: 'Allow'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '80'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: '*'
        }
      }
    ]
  }
}

// IP público estático (SKU Standard, como no Terraform)
resource pip 'Microsoft.Network/publicIPAddresses@2023-09-01' = {
  name: 'vm-lab-aula01-ip'
  location: location
  tags: tags
  sku: {
    name: 'Standard'
  }
  properties: {
    publicIPAllocationMethod: 'Static'
  }
}

// NSG vai anexado na NIC, não na subnet - mesma topologia do Terraform
resource nic 'Microsoft.Network/networkInterfaces@2023-09-01' = {
  name: 'vm-lab-aula01-nic'
  location: location
  tags: tags
  properties: {
    enableAcceleratedNetworking: true
    ipConfigurations: [
      {
        name: 'ipconfig1'
        properties: {
          privateIPAllocationMethod: 'Dynamic'
          subnet: {
            id: vnet.properties.subnets[0].id
          }
          publicIPAddress: {
            id: pip.id
          }
        }
      }
    ]
    networkSecurityGroup: {
      id: nsg.id
    }
  }
}

// Ubuntu 26.04 LTS ARM64, Standard_D2ps_v6, zona 1, trusted launch, spot instance,
// só autenticação por chave SSH
resource vm 'Microsoft.Compute/virtualMachines@2024-07-01' = {
  name: 'vm-lab-aula01'
  location: location
  zones: [
    zone
  ]
  tags: tags
  properties: {
    hardwareProfile: {
      vmSize: vmSize
    }
    priority: 'Spot'
    evictionPolicy: 'Deallocate'
    billingProfile: {
      maxPrice: -1
    }
    osProfile: {
      computerName: 'vm-lab-aula01'
      adminUsername: adminUsername
      linuxConfiguration: {
        disablePasswordAuthentication: true
        ssh: {
          publicKeys: [
            {
              path: '/home/${adminUsername}/.ssh/authorized_keys'
              keyData: adminPublicKey
            }
          ]
        }
      }
    }
    storageProfile: {
      imageReference: {
        publisher: 'canonical'
        offer: 'ubuntu-26_04-lts'
        sku: 'pro-server-arm64'
        version: 'latest'
      }
      osDisk: {
        caching: 'ReadWrite'
        createOption: 'FromImage'
        managedDisk: {
          storageAccountType: 'Premium_LRS'
        }
        diskSizeGB: 30
      }
      diskControllerType: 'SCSI'
    }
    networkProfile: {
      networkInterfaces: [
        {
          id: nic.id
        }
      ]
    }
    securityProfile: {
      securityType: 'TrustedLaunch'
      uefiSettings: {
        secureBootEnabled: true
        vTpmEnabled: true
      }
    }
    diagnosticsProfile: {
      bootDiagnostics: {
        enabled: true
      }
    }
  }
}

output resourceGroupName string = resourceGroup().name
output vmName string = vm.name
output publicIpAddress string = pip.properties.ipAddress
output sshCommand string = 'ssh ${adminUsername}@${pip.properties.ipAddress}'
output subnetAppId string = vnet.properties.subnets[1].id
