# qc-grupo-02-aula01

Entrega da Aula 1 (Fundamentos & IaC) — Grupo 2 — Cloud & Cognitive Environments

Documento principal: [`entrega-grupo-aula01.md`](entrega-grupo-aula01.md).

## Como rodar o nível 3 (bônus)

Tudo no **Azure Cloud Shell**

### Terraform (Exercício 3.1 — VM + rede endurecida)

```bash
cd terraform/
terraform init
terraform apply -var="meu_ip=$(curl -s ifconfig.me)"

# validar acesso
terraform output -raw ssh_command
ssh -i ~/.ssh/id_rsa <usuário>@<ip-publico>

# destruir tudo ao final
terraform destroy -var="meu_ip=$(curl -s ifconfig.me)"
```

`meu_ip` não tem valor padrão de propósito — precisa ser passado toda vez (com `curl ifconfig.me`), para nunca ficar hardcoded no código versionado. Isso também documenta, no próprio comando, como restringir o SSH ao IP de quem está rodando o lab naquele momento.

### Bicep (Exercício 3.2 — mesmo lab, sintaxe Bicep)

```bash
az group create --name rg-bicep-aula01 --location eastus2

az deployment group create \
  --resource-group rg-bicep-aula01 \
  --template-file bicep/main.bicep \
  --parameters adminPublicKey="$(cat ~/.ssh/id_rsa.pub)" meuIp="$(curl -s ifconfig.me)"

# destruir tudo ao final
az group delete --name rg-bicep-aula01 --yes --no-wait
```

### Diagrama (Exercício 2.1)

`diagramas/arquitetura-qc-aula01.svg` foi gerado como SVG.

## Estrutura

```
qc-grupo-02-aula01/
├── entrega-grupo-aula01.md   # documento principal (N1 + N2 + N3 + reflexão)
├── README.md                 # este arquivo
├── diagramas/
│   └── arquitetura-qc-aula01.svg
├── terraform/                # Exercício 3.1
│   ├── main.tf
│   ├── variables.tf
│   └── outputs.tf
└── bicep/                    # Exercício 3.2
    └── main.bicep
```
