# Entrega Aula 01 — Grupo 2

**Disciplina:** Cloud & Cognitive Environments

**Turma:** 1AIE

**Data de entrega:** 18/08/2026

## Grupo

| # | Nome completo | GitHub | E-mail FIAP |
|---|---------------|--------|-------------|
| 1 | Ksenia Busquet | `@kseniabusquet` | `rm371431@fiap.com.br` |
| 2 | Samuel Cupertino | `@samuelCupertino` | `rm371147@fiap.com.br` |
| 3 | Renato de Jesus Rocha | `@renatojesusrocha` | `rm373230@fiap.com.br`
| 4 | Henrique Guilherme Arduini | `@Mongruel` | `rm374349@fiap.com.br` |

## Distribuição do trabalho

| Membro | Nível assumido | Item específico |
|--------|----------------|-----------------|
| Samuel Cupertino | 🟢 N1 | Exercícios 1.1, 1.2, 1.3, 1.4 |
| Ksenia Busquet | 🟡 N2 | Exercício 2.1 — Arquitetura QC + diagrama |
| Renato de Jesus Rocha | 🟡 N2 | Exercícios 2.2 e 2.3 — Comparativo de custos e migração |
| Henrique Guilherme Arduini | 🔴 N3 (bônus) | Exercícios 3.1, 3.2, 3.3 — Terraform, Bicep, multi-cloud |


---

## 🟢 Nível 1 — Respostas

### Exercício 1.1 — Mapeamento de modelos de serviço

| Serviço | Modelo | Justificativa |
|---------|--------|----------------|
| Gmail | SaaS | Aplicação completa entregue ao usuário final; nada da infraestrutura é gerenciado por quem usa. |
| Azure Virtual Machines | IaaS | O usuário gerencia SO, patches e aplicações; o Azure só entrega hardware virtualizado (compute, disco, rede). |
| Azure App Service (hospedar uma API) | PaaS | O Azure gerencia SO e runtime; o time só faz deploy do código da API. |
| AWS Lambda | FaaS | Só se escreve a função; não existe servidor fixo, cobrança é por execução. |
| Azure SQL Database | PaaS | O Azure gerencia o motor do banco (patch, HA, backup); o time gerencia esquema e dados. |
| Salesforce CRM | SaaS | Aplicação de CRM completa entregue como serviço, sem gestão de infraestrutura. |
| Google Kubernetes Engine (GKE) | PaaS/IaaS (híbrido) | O time gerencia os workloads (pods, deployments); o GCP gerencia o plano de controle do Kubernetes. |
| Azure Blob Storage | PaaS | Armazenamento totalmente gerenciado; o time só define políticas (tiers, lifecycle, permissões). |
| Azure OpenAI Service | SaaS / API-as-a-Service | Consumo via API REST, sem gerenciar modelo, GPU ou infraestrutura de treino/inferência. |

### Exercício 1.2 — Os 6 Rs na prática

| Cenário | R escolhido | Justificativa |
|---------|-------------|----------------|
| **A** — Rastreamento de frotas, código de 2008, sem documentação, urgência de migrar | **Rehost** (Lift & Shift) | Não há tempo nem conhecimento interno para refatorar um sistema não documentado com um único mantenedor. Mover a VM para a nuvem como está já entrega elasticidade e reduz risco de hardware físico, com o menor esforço possível. |
| **B** — ERP de RH com <5 usuários ativos/mês, dados raramente consultados | **Retire** | O custo de migrar (replatform ou refactor) supera o valor gerado por um sistema quase sem uso. Os dados históricos podem ser arquivados em storage frio (Archive tier) para eventual auditoria, e o sistema é desligado. |
| **C** — API de pagamentos monolítica, empresa quer escalar e ganhar resiliência | **Refactor** | A decisão explícita de reescrever em microsserviços + event-driven indica que vale o maior esforço/investimento — pagamentos é um domínio crítico onde escalabilidade e resiliência justificam o retrabalho. |
| **D** — CRM interno de 15 anos, SaaS de mercado cobre 90% do uso por menor custo | **Repurchase** | Quando um SaaS consolidado (Salesforce/HubSpot) atende a maior parte da necessidade por um custo total menor que manter um sistema proprietário, a decisão é de negócio, não técnica — substituir é mais barato que manter. |
| **E** — Mainframe com dados de clientes, on-premise por exigência do Banco Central | **Retain** | Regulação (BACEN) obriga a manutenção on-premise. Isso não é uma falha da estratégia de cloud — é uma decisão legítima ditada por compliance. |

### Exercício 1.3 — Calculando o impacto do SLA

Sistema de e-commerce com **SLA de 99,9%**.

**a) Downtime anual:**

Downtime anual (h) = 8.760 × (1 − SLA/100) = 8.760 × (1 − 0,999) = 8.760 × 0,001 = **8,76 horas/ano** (≈ 525 minutos/ano)

**b) Impacto financeiro máximo:**

Impacto = 8,76 h × R$ 50.000/h = **R$ 438.000/ano**

**c) SLA mínimo para reduzir o impacto a menos de R$ 50.000/ano:**

Downtime máximo tolerável = R$ 50.000 ÷ R$ 50.000/h = 1 hora/ano

1 h ÷ 8.760 h = 0,0001142 → 0,01142% de downtime permitido → SLA mínimo ≈ **99,9886%**

Na prática, isso significa contratar o degrau padrão de mercado imediatamente acima: **SLA de 99,99%** ("quatro noves"), que permite ~52 minutos/ano de downtime — folga confortável abaixo do teto de 1 hora calculado, e ainda assim bem mais barato que perseguir 99,999%.

### Exercício 1.4 — RBAC na prática

| Perfil | Role Azure mais adequada | Justificativa |
|--------|---------------------------|----------------|
| Agente de IA que LÊ produtos do Storage para responder ao cliente | **Storage Blob Data Reader**, com escopo no container específico | O agente só precisa ler blobs de catálogo — nunca escrever, deletar ou gerenciar a conta de armazenamento. Escopo no container (não na storage account inteira) reduz ainda mais o raio de explosão. |
| Engenheiro de dados que CARREGA novos catálogos no Blob | **Storage Blob Data Contributor** | Precisa escrever/atualizar blobs, mas não precisa gerenciar permissões (`Owner`) nem configurações da conta. |
| Time de FinOps que precisa VER custos sem alterar recursos | **Cost Management Reader** (ou **Billing Reader**, conforme o escopo — assinatura vs. cobrança) | Acesso somente leitura ao plano de custos; não deve ter `Contributor`/`Owner`, que permitiria alterar recursos. |
| Auditor externo que precisa LER configurações de toda a assinatura | **Reader** na assinatura | Visibilidade completa de configuração (control plane) sem qualquer permissão de escrita — adequado para auditoria externa. |
| Sistema de CI/CD que provisiona infraestrutura via Terraform | **Contributor** escopado no Resource Group específico (não na assinatura), usando um **Service Principal dedicado** (ou Workload Identity Federation, sem client secret) | O pipeline precisa criar/alterar recursos, mas apenas dentro do RG que ele gerencia — nunca `Owner` nem escopo de assinatura inteira, para não conseguir alterar RBAC de outros times. |

**Princípio aplicado em todas as linhas:** menor privilégio — a role mais restrita que ainda permite a tarefa, no menor escopo possível (recurso/container > Resource Group > assinatura).

---

## 🟡 Nível 2 — Respostas + Implementação

### Exercício 2.1 — Arquitetura de alto nível: Quantum Commerce

**Contexto:** e-commerce presente em 12 países, 5M de SKUs, buscando transformar a experiência de compra com IA conversacional.

#### 1. Camadas da arquitetura

1. **Canais** — web, app mobile, chatbot/voz (o agente conversacional em si) e API para parceiros B2B, atrás de um CDN/Front Door para latência e cache.
2. **API & Orquestração** — camada de backend que expõe as regras de negócio (catálogo, pedidos, estoque) e orquestra as chamadas ao agente de IA; inclui filas/mensageria para desacoplar processos assíncronos (ex.: confirmação de pedido, notificação).
3. **IA & Agentes** — LLM (Azure OpenAI), busca vetorial/RAG (Azure AI Search) sobre o catálogo e reviews, e serviços cognitivos (visão computacional para busca por imagem, fala para o canal de voz).
4. **Dados** — object storage para catálogo/imagens, banco relacional para transações (pedidos, estoque, pagamento — onde ACID importa), banco NoSQL para dados de alto volume e schema variável (reviews, sessões, carrinho), e Key Vault para segredos.
5. **Observabilidade & Segurança** (transversal a todas as camadas) — monitoramento centralizado, RBAC e Managed Identity por agente/serviço, seguindo o princípio do menor privilégio.

Ver diagrama completo em [`diagramas/arquitetura-qc-aula01.png`](../diagramas/arquitetura-qc-aula01.png).

#### 2. Provedor principal

**Azure**, pelos seguintes motivos:

- Crédito educacional da parceria FIAP (US$ 100/aluno) e todo o material do curso já é construído em cima do ecossistema Azure — reduz a curva de aprendizado
- Integração nativa entre **Azure OpenAI + Azure AI Search + Cosmos DB + Managed Identity**, que é exatamente a combinação necessária para um chatbot de IA conversacional com RAG sobre o catálogo — construir essa mesma integração de forma nativa em outro provedor exigiria mais peças soltas.
- Governança de identidade (Entra ID + RBAC + Managed Identity) madura o suficiente para aplicar o princípio de menor privilégio a cada agente de IA individualmente, tema central da disciplina.
- Não descarta multi-cloud pontual (ver Exercício 3.3) para cargas específicas onde outro provedor é claramente superior (ex.: analytics em BigQuery).

#### 3. Serviços por categoria

| Categoria | Serviço Azure | Alternativa AWS | Alternativa GCP |
|-----------|----------------|------------------|-------------------|
| Compute (backend) | App Service / AKS | ECS/EKS | Cloud Run / GKE |
| Storage (catálogo, imagens) | Blob Storage | S3 | Cloud Storage (GCS) |
| Banco relacional | Azure SQL Database | RDS / Aurora | Cloud SQL |
| Banco NoSQL | Cosmos DB | DynamoDB | Firestore |
| Vector Database | Azure AI Search / Cosmos DB Vector | Amazon OpenSearch (k-NN) | Vertex AI Vector Search |
| Serviços de IA cognitivos | Azure AI Services + Azure OpenAI | Bedrock + Rekognition/Comprehend | Vertex AI |
| CDN | Azure Front Door + CDN | CloudFront | Cloud CDN |
| Mensageria/Filas | Service Bus / Event Grid | SQS / SNS | Pub/Sub |
| Observabilidade (logs/métricas) | Azure Monitor + Application Insights + Log Analytics | CloudWatch | Cloud Monitoring / Cloud Logging |

#### 4. Diagrama

Arquivo: [`diagramas/arquitetura-qc-aula01.png`](../diagramas/arquitetura-qc-aula01.png) (as 5 camadas acima, com os serviços Azure escolhidos e o fluxo entre elas). Este esboço é a base que evolui a cada entrega até a versão final na Aula 6.

---

### Exercício 2.2 — Comparativo de custos: 3 provedores

**Cenário:** 2 VMs (2 vCPU / 8 GB RAM, Linux, 24/7) · 500 GB de object storage · 1 banco gerenciado (2 vCPU / 8 GB / 100 GB) · 10M requisições/mês em função serverless.

| Item | Azure | AWS | GCP | Notas |
|------|-------|-----|-----|-------|
| 2 × VM (2vCPU/8GB) | US$ 140,16 | US$ 140,16 | US$ 97,82 | Tipo: `D2s_v3` (Azure) · `m5.large` (AWS) · `e2-standard-2` (GCP) — todos ~730 h/mês |
| 500 GB storage | US$ 9,00 | US$ 11,50 | US$ 10,00 | Tier "hot"/standard em todos; Azure Blob é o mais barato dos três nesse tier |
| Banco gerenciado | US$ 380,00 | US$ 141,00 | US$ 138,00 | Tipo: Azure SQL DB GP 2 vCore (Gen5) · RDS PostgreSQL `db.m5.large` · Cloud SQL PostgreSQL — **ver nota abaixo sobre paridade de motor** |
| 10M req serverless | US$ 7,00 | US$ 7,00 | US$ 5,00 | Azure Functions / AWS Lambda / GCP Cloud Functions, plano consumo |
| **Total mensal** | **US$ 536,16** | **US$ 299,66** | **US$ 250,82** | |
| **Total anual** | **US$ 6.433,92** | **US$ 3.595,92** | **US$ 3.009,84** | |

**a) Qual provedor ficou mais barato? A diferença é significativa?**

GCP ficou mais barato no total (~US$ 3.010/ano), seguido de perto por AWS (~US$ 3.596/ano). O Azure aparece ~78% mais caro que o GCP no total anual — mas essa diferença é dominada quase inteiramente pela linha do banco de dados gerenciado (que, como observado acima, não está comparando o mesmo motor). Se normalizarmos a comparação para o mesmo motor (SQL Server em todos), a diferença entre os três provedores cai para algo bem mais próximo de 10-20%, não de 80%.

**b) Aplicando Reserved Instances de 1 ano no mais caro (Azure), o resultado muda?**

Sim, de forma relevante. Reservando por 1 ano tipicamente se obtém ~30-40% de desconto em compute e ~30% em banco gerenciado:

- VM: US$ 140,16 → ~US$ 91,00/mês (35% off)
- Banco: US$ 380,00 → ~US$ 266,00/mês (30% off)
- Novo total mensal Azure: ~US$ 372,00 → **~US$ 4.466/ano**

Isso reduz a diferença de "Azure é 78% mais caro que GCP" para "Azure é ~24% mais caro que o total pay-as-you-go do GCP" — ainda mais caro, mas a distância cai bastante. Vale notar que reserva é um compromisso financeiro de 1-3 anos, então só compensa para a carga que o grupo sabe, com razoável confiança, que vai rodar 24/7 durante esse período (não para ambientes de dev/test).

**c) Além de preço, que outros fatores considerar para um projeto de IA?**

- **Integração nativa com IA generativa/RAG:** a combinação Azure OpenAI + AI Search + Managed Identity (usada nos labs) reduz esforço de integração comparado a montar o mesmo pipeline "colando" serviços de provedores diferentes.
- **Disponibilidade de região e residência de dados:** para uma operação com 12 países (incluindo Brasil), confirmar que os serviços necessários (incluindo Azure OpenAI, que nem sempre está disponível em todas as regiões) existem na região exigida por LGPD/compliance local.
- **Maturidade do ecossistema de vetores/RAG:** ponto central para o chatbot da QC — vale avaliar throughput, latência e custo por consulta do vector DB sob carga real, não só o preço "de tabela".
- **Skillset da equipe e vínculo contratual:** o crédito educacional é Azure; em produção, contratos corporativos existentes (desconto por volume, suporte premium) podem inverter a conta de custo puro.
- **Lock-in vs. portabilidade:** quanto mais a arquitetura depender de serviços proprietários (ex.: Cosmos DB, AI Search), maior o custo de eventualmente trocar de provedor — decisão consciente, não acidental.

---

### Exercício 2.3 — Estratégia de migração para meu contexto profissional

**a) Sistema/workload (genérico, sem dados confidenciais):**

Um portal de relatórios e dashboards de pesquisa de mercado/ponto de venda para associados de uma instituição do setor de varejo e trade marketing, rodando há cerca de 8 anos em servidor físico on-premise. O uso é fortemente sazonal — picos de acesso em datas comerciais (Black Friday, Natal, lançamentos de campanhas) e demanda baixa no resto do ano, o que deixa o servidor físico ocioso na maior parte do tempo e sob risco de saturação nos picos.

**b) Qual dos 6 Rs? Justificativa de custo, risco, ganho e prazo:**

**Replatform.** A aplicação em si (lógica de geração de relatórios, autenticação de associados) não precisa ser reescrita — mas trocar o banco de dados local por um banco gerenciado (Azure SQL Database, com **serverless/auto-pause** para os períodos de baixa demanda) e mover a camada web para **Azure App Service com auto-scaling** captura o ganho real da nuvem para esse padrão de uso sazonal, sem o custo/risco de um refactor completo.

- **Custo:** esforço moderado (adaptar connection strings, mover para Key Vault, configurar auto-scaling) — bem menor que reescrever a aplicação.
- **Risco:** baixo a moderado — a lógica de negócio não muda, o principal risco é na migração de dados e no período de dupla operação (paralelo).
- **Ganho:** alto para o padrão sazonal — pagar por capacidade elástica nos picos e quase nada (auto-pause) fora deles, em vez de manter hardware físico dimensionado para o pico o ano inteiro.
- **Prazo:** médio (algumas semanas), viável em um projeto piloto controlado antes de descomissionar o servidor físico.

**c) Que serviço Azure? Estimativa mensal?**

Azure App Service (plano B1/S1, com scale-out automático nos picos) + Azure SQL Database Serverless (2 vCore, auto-pause) + Blob Storage para exportação de relatórios (PDF/Excel). Estimativa: ~R$ 1.500–3.000/mês em operação normal, com picos pontuais mais altos apenas nos meses de campanha — ainda assim, tipicamente mais barato que o custo total de propriedade (energia, manutenção, depreciação) do servidor físico dimensionado para o pico.

**d) Maior obstáculo técnico ou organizacional? Como endereçar?**

O maior obstáculo tende a ser organizacional, não técnico: resistência a mudar um sistema "que já funciona há 8 anos" e a falta de familiaridade da equipe interna com operação em nuvem. Isso se endereça com um piloto em paralelo (o sistema on-premise continua rodando enquanto a versão migrada é validada com um grupo pequeno de usuários), métricas objetivas de custo e desempenho comparando antes/depois, e capacitação da equipe interna — inclusive aproveitando o conteúdo desta própria disciplina como base de treinamento.

---

## 🔴 Nível 3 — Bônus

### Exercício 3.1 — Terraform: endurecer a segurança de rede da VM

Código completo em [`terraform/main.tf`](../terraform/main.tf), [`terraform/variables.tf`](../terraform/variables.tf) e [`terraform/outputs.tf`](../terraform/outputs.tf). Resumo do diff em relação ao lab original (`aulas/01-fundamentos-iac/lab/terraform/`):

1. **SSH restrito ao IP do operador** — a regra `SSH` do `azurerm_network_security_group.nsg` trocou `source_address_prefix = "*"` por `source_address_prefix = "${var.meu_ip}/32"`. A nova variável `meu_ip` (em `variables.tf`) **não tem default** — é obrigatório passar o valor (`terraform apply -var="meu_ip=$(curl -s ifconfig.me)"`), justamente para não deixar um IP hardcoded no código versionado. Uma `validation` garante que o valor tenha formato de IPv4 antes de aplicar.
2. **Segunda subnet `subnet-app`** (`10.0.2.0/24`) adicionada à mesma VNet (`10.0.0.0/16`), isolando logicamente a futura camada de aplicação da QC da subnet de gerenciamento/lab (`10.0.0.0/24`). Não há conflito de endereçamento — ambas cabem dentro do bloco /16 original.
3. **Output do IP público** — `public_ip_address` já existia no lab original e continua presente; adicionamos também `subnet_app_id` para expor o identificador da nova subnet.
4. **Efeito no `terraform plan`:** como só a regra `source_address_prefix` do NSG mudou (e uma subnet nova foi *adicionada*, não substituída), o plano mostra **update in-place** no `azurerm_network_security_group.nsg` e **create** para `azurerm_subnet.app` — a VM, a NIC e o IP público **não são recriados**, porque nenhum atributo `ForceNew` deles foi alterado.

```
# Resumo do `terraform plan`:
  ~ resource "azurerm_network_security_group" "nsg" {
      ~ security_rule {
          ~ source_address_prefix = "*" -> "203.0.113.42/32"   # regra "SSH"
        }
    }
  + resource "azurerm_subnet" "app" {
      + name             = "subnet-app"
      + address_prefixes = ["10.0.2.0/24"]
    }

Plan: 1 to add, 1 to change, 0 to destroy.
```

**Como aplicar:**

```bash
cd terraform/
terraform init
terraform apply -var="meu_ip=$(curl -s ifconfig.me)"
# ... validar acesso SSH normalmente ...
terraform destroy -var="meu_ip=$(curl -s ifconfig.me)"
```

### Exercício 3.2 — Bicep equivalente

Código completo em [`bicep/main.bicep`](../bicep/main.bicep), já incorporando o mesmo hardening do Exercício 3.1 (parâmetro `meuIp`, subnet `subnet-app`).

**Deploy:**

```bash
az group create --name rg-bicep-aula01 --location eastus2

az deployment group create \
  --resource-group rg-bicep-aula01 \
  --template-file bicep/main.bicep \
  --parameters adminPublicKey="$(cat ~/.ssh/id_rsa.pub)" meuIp="$(curl -s ifconfig.me)"

az group delete --name rg-bicep-aula01 --yes --no-wait
```

**Comparação dos três artefatos:**

| Artefato | Linhas (aprox.) | Legibilidade | Quando escolher |
|----------|------------------|----------------|-------------------|
| `template.json` (ARM) | ~250-300 | Baixa — JSON verboso, difícil de revisar em PR | Praticamente nunca escrito à mão hoje; existe como formato de exportação/compilação |
| `main.tf` (Terraform) | ~175 | Média-alta — HCL é declarativo e legível, mas exige entender o provider `azurerm` | Time já usa Terraform em outras nuvens, quer portabilidade e o ecossistema gigante de módulos/providers |
| `main.bicep` | ~150 | Alta — sintaxe mais enxuta que HCL para o mesmo recurso, tipagem nativa dos recursos Azure com autocomplete no VS Code | Ambiente 100% Azure, equipe já é "Microsoft-shop", quer a integração nativa com ARM/Azure Policy sem instalar nada extra |

O **Bicep ficou mais legível** para este recurso específico (menos aninhamento que o `.tf`, nomes de propriedade iguais aos da documentação do Azure), mas o **Terraform** continua sendo a escolha da disciplina porque a Quantum Commerce não descarta multi-cloud pontual (Exercício 3.3) — e o Bicep simplesmente não se aplica fora do Azure.

### Exercício 3.3 — Desafio de arquitetura: multi-cloud para a Quantum Commerce

**a) Arquitetura multi-cloud (2 provedores):**

- **Azure (primário):** toda a camada transacional e de agentes — compute (App Service/AKS), Azure SQL, Cosmos DB, Blob Storage, Azure OpenAI + AI Search para o RAG do chatbot. Justificativa: é onde a QC já opera, com a integração nativa de IA generativa necessária para a experiência conversacional em tempo real, que é sensível a latência.
- **GCP (secundário, analytics):** os dados transacionais são replicados via pipeline de ETL/ELT (batch, não síncrono) do Azure Blob/SQL para o **BigQuery**, usado para relatórios executivos, modelos de ML de recomendação treinados sobre o histórico completo (Vertex AI) e dashboards de BI. Justificativa: GCP tem vantagem reconhecida em data warehouse analítico e ferramental de ML/estatística — carga que tolera bem a latência de um pipeline batch e se beneficia do preço/performance do BigQuery para consultas analíticas pesadas.

**b) Quatro desafios principais:**

| Desafio | Descrição | Mitigação proposta |
|---------|-----------|----------------------|
| Latência entre nuvens | Chamadas síncronas Azure ↔ GCP adicionam latência de rede entre provedores, inaceitável para o caminho crítico do chatbot | Manter o caminho síncrono (agente conversacional) 100% dentro do Azure; a ida para o GCP é sempre assíncrona/batch (ETL agendado), nunca no caminho de resposta ao cliente |
| Identidade unificada | Azure usa Entra ID/Managed Identity; GCP usa IAM próprio — não há um "RBAC único" nativo entre os dois | Federar via **Workload Identity Federation** (GCP) recebendo tokens do Entra ID, evitando duplicar credenciais estáticas em cada nuvem |
| Custos de egress | Tráfego saindo do Azure em direção ao GCP é cobrado por GB; em volume, essa linha pode superar o custo de compute | Comprimir e agendar as cargas de ETL para lotes fora de horário de pico, e transferir apenas os dados necessários para analytics (não o dataset completo) |
| Observabilidade | Azure Monitor não enxerga recursos do GCP nativamente, e vice-versa — risco de "pontos cegos" na operação | Consolidar logs/métricas das duas nuvens em uma ferramenta central agnóstica de provedor (ex.: Grafana + Prometheus, ou um SIEM corporativo), em vez de depender só das ferramentas nativas de cada nuvem |

**c) Terraform vs. Pulumi:**

| Critério | Terraform | Pulumi |
|----------|-----------|--------|
| Linguagem | HCL (declarativa, própria da ferramenta) | Linguagens de propósito geral (Python, TypeScript, Go, C#) |
| Pricing | Núcleo open-source gratuito; HCP Terraform (antigo Terraform Cloud) paga por usuário/recursos gerenciados em escala | Gratuito para uso individual; planos pagos para times/organizações com recursos de colaboração |
| Suporte aos 3 grandes | Excelente — providers oficiais `azurerm`, `aws`, `google`, maior ecossistema de módulos do mercado | Excelente também — usa os mesmos providers do Terraform "por baixo" (bridged), mais SDKs nativos para alguns serviços |
| Quando escolher | Time focado em infraestrutura, quer o padrão de facto do mercado, prioriza HCL declarativo simples e curva de aprendizado mais rasa para quem nunca programou | Time de desenvolvimento que já domina uma linguagem de propósito geral e quer reaproveitar testes unitários, loops/condicionais reais e abstrações de código para a infraestrutura |

Para a disciplina e para a QC hoje, **Terraform** continua sendo a escolha mais pragmática — a equipe de infraestrutura não é necessariamente um time de devs, e o ecossistema de módulos prontos multi-cloud reduz retrabalho.

**d) Estimativa de custo de egress — 10 TB/mês, Azure (Brazil South) → AWS (us-east-1):**

Usando a tarifa pública de saída de dados do Azure (~US$ 0,087/GB na faixa até 10 TB/mês, após os primeiros 100 GB gratuitos mensais):

10.000 GB × US$ 0,087/GB ≈ **US$ 870/mês** (≈ **US$ 10.440/ano**) apenas de egress do lado Azure.

(A entrada de dados do lado AWS — *data transfer IN* — costuma ser gratuita; o custo relevante está concentrado na saída do Azure.) Esse valor por si só já é maior que o custo mensal total de compute do cenário do Exercício 2.2 — reforça por que, na arquitetura proposta no item (a), preferimos mandar para fora do Azure apenas o subconjunto de dados necessário para analytics, e não o dataset completo.

---

## Reflexão coletiva

O aprendizado mais importante desta aula foi perceber que **Infraestrutura como Código não é sobre economizar cliques — é sobre reprodutibilidade**. A diferença entre criar a VM manualmente pelo portal e recriá-la via Terraform não está no tempo total gasto (o portal até pode ser mais rápido na primeira vez), mas no fato de que o código versionado permite que qualquer pessoa do grupo recrie exatamente o mesmo ambiente, revise a mudança em um PR antes de aplicá-la, e destrua tudo com um único comando ao final — algo praticamente impossível de garantir com cliques manuais em escala.

Essa reprodutibilidade se conecta diretamente com a arquitetura de uma plataforma agentic como a Quantum Commerce: um agente de IA em produção não pode depender de um ambiente "configurado uma vez à mão" — ele precisa de infraestrutura determinística (o mesmo `terraform apply` gera o mesmo resultado em dev, homologação e produção), de identidade própria com o menor privilégio possível (Managed Identity, nunca client secret hardcoded), e de segredos versionados fora do código (Key Vault, nunca connection string no repositório). Cada um desses princípios discutidos na Aula 1 — 6 Rs, SLA, RBAC, IaC — reaparece de forma prática assim que se pensa em colocar um agente de IA para operar de verdade, com dados reais e custo real por trás.

Se o grupo começasse o projeto Quantum Commerce hoje, a principal decisão que faríamos diferente seria **desenhar o hardening de rede (Exercício 3.1) desde o primeiro `apply`**, e não como um exercício bônus posterior — ou seja, nunca deixar uma regra `source_address_prefix = "*"` sequer temporariamente em um ambiente que vai evoluir para produção. Também formalizaríamos mais cedo a separação de Resource Groups por domínio (dados, aplicação, IA) sugerida no diagrama do Exercício 2.1, em vez de deixar tudo em um único RG "de lab" — facilita aplicar RBAC e controle de custo por camada desde o início, ao invés de reorganizar depois.

---

## Artefatos do ZIP

- Diagrama: `diagramas/arquitetura-qc-aula01.png`
- Código IaC: `terraform/` (Exercício 3.1) e `bicep/` (Exercício 3.2)
